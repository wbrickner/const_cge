# Shared Activations Crate

- This is a support crate for `const_cge`, allowing all generated code to reuse the same activation implementations.

- If you want to use `const_cge`, you're in the wrong place.
## Visit [`const_cge`](https://crates.io/crates/const_cge)